# Providers

provider "aws" {
  alias  = "mumbai"
  region = var.mumbai_region
}

provider "aws" {
  alias  = "virginia"
  region = var.virginia_region
}

# Mumbai VPC Module
module "vpc_mumbai" {
  source  = "terraform-aws-modules/vpc/aws"
  version = "6.6.0"

  providers = {
    aws = aws.mumbai
  }

  name = "vpc_mumbai"
  cidr = var.mumbai_cidr
  azs = var.mumbai_azs
  public_subnets = var.mumbai_public_subnets

  enable_nat_gateway = false
}

# Virginia VPC Module
module "vpc_virginia" {
  source  = "terraform-aws-modules/vpc/aws"
  version = "6.6.0"

  providers = {
    aws = aws.virginia
  }

  name = "vpc_virginia"
  cidr = var.virginia_cidr
  azs = var.virginia_azs
  public_subnets = var.virginia_public_subnets

  enable_nat_gateway = false
}

# Mumbai-SG
resource "aws_security_group" "mumbai_sg" {
  provider = aws.mumbai

  name   = "mumbai-sg"
  vpc_id = module.vpc_mumbai.vpc_id

  ingress {
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

# Virginia_SG
resource "aws_security_group" "virginia_sg" {
  provider = aws.virginia

  name   = "virginia-sg"
  vpc_id = module.vpc_virginia.vpc_id

  ingress {
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

# 1st EC2
resource "aws_instance" "mumbai_ec2" {
  provider = aws.mumbai

  ami = var.mumbai_ami
  instance_type = var.instance_type
  key_name      = "test_key_mum"

  subnet_id = module.vpc_mumbai.public_subnets[0]
  associate_public_ip_address = true
  vpc_security_group_ids = [aws_security_group.mumbai_sg.id]

  connection {
    type = "ssh"
    user = "ubuntu"
    private_key = file("test_key_mum.pem")
    host = self.public_ip
  }

  provisioner "remote-exec" {
    inline = [ 
        "sudo apt-get update -y",
        "sudo apt install nginx -y",
        "sudo systemctl start nginx",
        "sudo systemctl enable nginx" 
        ]
  }

  tags = {
    Name = "mumbai-ec2"
  }
}

# 2nd EC2
resource "aws_instance" "virginia_ec2" {
  provider = aws.virginia

  ami = var.virginia_ami
  instance_type = var.instance_type
  key_name = "test_key"

  subnet_id = module.vpc_virginia.public_subnets[0]
  associate_public_ip_address = true
  vpc_security_group_ids = [aws_security_group.virginia_sg.id]

  connection {
    type = "ssh"
    user = "ubuntu"
    private_key = file("test_key.pem")
    host = self.public_ip
  }

  provisioner "remote-exec" {
    inline = [ 
        "sudo apt-get update -y",
        "sudo apt install nginx -y",
        "sudo systemctl start nginx",
        "sudo systemctl enable nginx" 
     ]
  }

  tags = {
    Name = "virginia-ec2"
  }
}