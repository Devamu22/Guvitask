# Providers

provider "aws" {
  alias  = "mumbai"
  region = var.mumbai_region
}

provider "aws" {
  alias  = "virginia"
  region = var.virginia_region
}

# Mumbai VPC Module
module "vpc_mumbai" {
  source  = "terraform-aws-modules/vpc/aws"
  version = "6.6.0"

  providers = {
    aws = aws.mumbai
  }

  name = "vpc_mumbai"
  cidr = var.mumbai_cidr
  azs = var.mumbai_azs
  public_subnets = var.mumbai_public_subnets

  enable_nat_gateway = false
}

# Virginia VPC Module
module "vpc_virginia" {
  source  = "terraform-aws-modules/vpc/aws"
  version = "6.6.0"

  providers = {
    aws = aws.virginia
  }

  name = "vpc_virginia"
  cidr = var.virginia_cidr
  azs = var.virginia_azs
  public_subnets = var.virginia_public_subnets

  enable_nat_gateway = false
}

# 1st EC2
resource "aws_instance" "mumbai_ec2" {
  provider = aws.mumbai

  ami = var.mumbai_ami
  instance_type = var.instance_type

  subnet_id = module.vpc_mumbai.public_subnets[0]

  tags = {
    Name = "mumbai-ec2"
  }
}

# 2nd EC2
resource "aws_instance" "virginia_ec2" {
  provider = aws.virginia

  ami = var.virginia_ami
  instance_type = var.instance_type

  subnet_id = module.vpc_virginia.public_subnets[0]

  tags = {
    Name = "virginia-ec2"
  }
}