variable "mumbai_region" {
  description = "AWS region for Mumbai"
  type = string
}

variable "virginia_region" {
  description = "AWS region for Virginia"
}

variable "mumbai_cidr" {
  description = "Mumbai VPC CIDR range"
  type = string
}

variable "mumbai_azs" {
  description = "Mumbai availability zones"
  type = list(string)
}

variable "mumbai_public_subnets" {
  description = "Mumbai's public subnet's CIDR range"
  type = list(string)
}

variable "virginia_cidr" {
  description = "Virginia's VPC CIDR range"
  type = string
}

variable "virginia_azs" {
  description = "Virginia's availability zones"
  type = list(string)
}

variable "virginia_public_subnets" {
  description = "Virginia's public subnet's CIDR range"
  type = list(string)
}

variable "instance_type" {
  description = "The instance type"
  type = string
}

variable "mumbai_ami" {
  description = "AMI ID for Mumbai region"
  type = string
}

variable "virginia_ami" {
  description = "AMI ID for Virginia region"
  type = string
}