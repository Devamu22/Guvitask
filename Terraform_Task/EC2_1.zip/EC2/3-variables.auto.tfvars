mumbai_region   = "ap-south-1"

virginia_region = "us-east-1"

mumbai_cidr = "10.0.0.0/16"

virginia_cidr = "10.1.0.0/16"

mumbai_public_subnets = [ "10.0.1.0/24", "10.0.2.0/24" ]

virginia_public_subnets = [ "10.1.1.0/24", "10.1.2.0/24" ]

mumbai_azs = [ "ap-south-1a", "ap-south-1b" ]

virginia_azs = [ "us-east-1a", "us-east-1b" ]

mumbai_ami = "ami-05d2d839d4f73aafb"

virginia_ami = "ami-0ec10929233384c7f"

instance_type = "t2.micro"